#pragma once

#include <cstddef>
#include <stdexcept>

// Шаблонный класс для однозвязного циклического списка (кольца)
template <typename T>
class CircularList {
private:
    struct Node {
        T data;
        Node* next;

        Node(const T& value) : data(value), next(nullptr) {}
    };

    Node* m_head;
    std::size_t m_size;

public:
    // Конструктор
    CircularList() : m_head(nullptr), m_size(0) {}

    // Деструктор
    ~CircularList() {
        clear();
    }

    // Копирующий конструктор
    CircularList(const CircularList& other) : m_head(nullptr), m_size(0) {
        if (other.m_size > 0) {
            Node* current = other.m_head;
            for (std::size_t i = 0; i < other.m_size; ++i) {
                push_back(current->data);
                current = current->next;
            }
        }
    }

    // Оператор присваивания
    CircularList& operator=(const CircularList& other) {
        if (this != &other) {
            clear();
            if (other.m_size > 0) {
                Node* current = other.m_head;
                for (std::size_t i = 0; i < other.m_size; ++i) {
                    push_back(current->data);
                    current = current->next;
                }
            }
        }
        return *this;
    }

    // Добавить элемент в конец списка
    void push_back(const T& value) {
        Node* newNode = new Node(value);
        if (m_head == nullptr) {
            m_head = newNode;
            m_head->next = m_head;
        } else {
            Node* tail = m_head;
            while (tail->next != m_head) {
                tail = tail->next;
            }
            tail->next = newNode;
            newNode->next = m_head;
        }
        ++m_size;
    }

    // Добавить элемент в начало списка
    void push_front(const T& value) {
        Node* newNode = new Node(value);
        if (m_head == nullptr) {
            m_head = newNode;
            m_head->next = m_head;
        } else {
            Node* tail = m_head;
            while (tail->next != m_head) {
                tail = tail->next;
            }
            newNode->next = m_head;
            tail->next = newNode;
            m_head = newNode;
        }
        ++m_size;
    }

    // Удалить первый элемент
    void pop_front() {
        if (m_head == nullptr) {
            throw std::underflow_error("Попытка удаления из пустого списка");
        }
        if (m_size == 1) {
            delete m_head;
            m_head = nullptr;
        } else {
            Node* tail = m_head;
            while (tail->next != m_head) {
                tail = tail->next;
            }
            Node* temp = m_head;
            m_head = m_head->next;
            tail->next = m_head;
            delete temp;
        }
        --m_size;
    }

    // Удалить последний элемент
    void pop_back() {
        if (m_head == nullptr) {
            throw std::underflow_error("Попытка удаления из пустого списка");
        }
        if (m_size == 1) {
            delete m_head;
            m_head = nullptr;
        } else {
            Node* current = m_head;
            while (current->next->next != m_head) {
                current = current->next;
            }
            delete current->next;
            current->next = m_head;
        }
        --m_size;
    }

    // Получить первый элемент
    T& front() {
        if (m_head == nullptr) {
            throw std::underflow_error("Список пуст");
        }
        return m_head->data;
    }

    const T& front() const {
        if (m_head == nullptr) {
            throw std::underflow_error("Список пуст");
        }
        return m_head->data;
    }

    // Получить последний элемент
    T& back() {
        if (m_head == nullptr) {
            throw std::underflow_error("Список пуст");
        }
        Node* tail = m_head;
        while (tail->next != m_head) {
            tail = tail->next;
        }
        return tail->data;
    }

    const T& back() const {
        if (m_head == nullptr) {
            throw std::underflow_error("Список пуст");
        }
        Node* tail = m_head;
        while (tail->next != m_head) {
            tail = tail->next;
        }
        return tail->data;
    }

    // Получить размер списка
    std::size_t size() const noexcept {
        return m_size;
    }

    // Проверить, пуст ли список
    bool empty() const noexcept {
        return m_size == 0;
    }

    // Очистить список
    void clear() {
        if (m_head == nullptr) {
            return;
        }
        Node* current = m_head;
        for (std::size_t i = 0; i < m_size; ++i) {
            Node* next = current->next;
            delete current;
            current = next;
        }
        m_head = nullptr;
        m_size = 0;
    }

    // Найти элемент в списке
    bool contains(const T& value) const {
        if (m_head == nullptr) {
            return false;
        }
        Node* current = m_head;
        for (std::size_t i = 0; i < m_size; ++i) {
            if (current->data == value) {
                return true;
            }
            current = current->next;
        }
        return false;
    }

    // Получить элемент по индексу
    T& at(std::size_t index) {
        if (index >= m_size) {
            throw std::out_of_range("Индекс вне диапазона");
        }
        Node* current = m_head;
        for (std::size_t i = 0; i < index; ++i) {
            current = current->next;
        }
        return current->data;
    }

    const T& at(std::size_t index) const {
        if (index >= m_size) {
            throw std::out_of_range("Индекс вне диапазона");
        }
        Node* current = m_head;
        for (std::size_t i = 0; i < index; ++i) {
            current = current->next;
        }
        return current->data;
    }

    // Оператор доступа по индексу
    T& operator[](std::size_t index) {
        return at(index);
    }

    const T& operator[](std::size_t index) const {
        return at(index);
    }

    // Удалить элемент по значению
    bool remove(const T& value) {
        if (m_head == nullptr) {
            return false;
        }

        // Если это первый элемент
        if (m_head->data == value) {
            pop_front();
            return true;
        }

        Node* current = m_head;
        for (std::size_t i = 0; i < m_size - 1; ++i) {
            if (current->next->data == value) {
                Node* temp = current->next;
                current->next = temp->next;
                delete temp;
                --m_size;
                return true;
            }
            current = current->next;
        }
        return false;
    }

    // Вставить элемент в позицию
    void insert(std::size_t index, const T& value) {
        if (index > m_size) {
            throw std::out_of_range("Индекс вне диапазона");
        }
        if (index == 0) {
            push_front(value);
        } else if (index == m_size) {
            push_back(value);
        } else {
            Node* newNode = new Node(value);
            Node* current = m_head;
            for (std::size_t i = 0; i < index - 1; ++i) {
                current = current->next;
            }
            newNode->next = current->next;
            current->next = newNode;
            ++m_size;
        }
    }

    // Класс итератора
    class Iterator {
    private:
        Node* m_current;
        Node* m_head;
        std::size_t m_position;
        std::size_t m_size;

    public:
        Iterator(Node* current, Node* head, std::size_t position, std::size_t size)
            : m_current(current), m_head(head), m_position(position), m_size(size) {}

        T& operator*() {
            return m_current->data;
        }

        T* operator->() {
            return &m_current->data;
        }

        Iterator& operator++() {
            if (m_position < m_size) {
                m_current = m_current->next;
                ++m_position;
            }
            return *this;
        }

        Iterator operator++(int) {
            Iterator temp = *this;
            ++(*this);
            return temp;
        }

        bool operator==(const Iterator& other) const {
            return m_position == other.m_position && m_size == other.m_size;
        }

        bool operator!=(const Iterator& other) const {
            return !(*this == other);
        }
    };

    // Получить итератор на начало
    Iterator begin() {
        return Iterator(m_head, m_head, 0, m_size);
    }

    // Получить итератор на конец
    Iterator end() {
        return Iterator(nullptr, m_head, m_size, m_size);
    }
};
