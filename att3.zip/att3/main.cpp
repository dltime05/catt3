#include <iostream>
#include <string>

#ifdef _WIN32
#include <windows.h>
#endif

#include "CircularList.h"

int main() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif

    std::cout << "=== Однозвязный циклический список (кольцо) ===\n\n";

    // Пример 1: Работа со списком целых чисел (int)
    std::cout << "1. Список целых чисел:\n";
    CircularList<int> intList;

    intList.push_back(10);
    intList.push_back(20);
    intList.push_back(30);
    intList.push_back(40);

    std::cout << "   Добавлены элементы: 10, 20, 30, 40\n";
    std::cout << "   Размер списка: " << intList.size() << "\n";
    std::cout << "   Элементы списка: ";
    for (std::size_t i = 0; i < intList.size(); ++i) {
        std::cout << intList[i] << " ";
    }
    std::cout << "\n";

    std::cout << "   Первый элемент: " << intList.front() << "\n";
    std::cout << "   Последний элемент: " << intList.back() << "\n";

    intList.push_front(5);
    std::cout << "   После push_front(5): ";
    for (std::size_t i = 0; i < intList.size(); ++i) {
        std::cout << intList[i] << " ";
    }
    std::cout << "\n";

    intList.pop_back();
    std::cout << "   После pop_back(): ";
    for (std::size_t i = 0; i < intList.size(); ++i) {
        std::cout << intList[i] << " ";
    }
    std::cout << "\n";

    std::cout << "   Содержит 20? " << (intList.contains(20) ? "Да" : "Нет") << "\n";
    std::cout << "   Содержит 100? " << (intList.contains(100) ? "Да" : "Нет") << "\n";

    intList.remove(20);
    std::cout << "   После удаления 20: ";
    for (std::size_t i = 0; i < intList.size(); ++i) {
        std::cout << intList[i] << " ";
    }
    std::cout << "\n\n";

    // Пример 2: Работа со списком строк (string)
    std::cout << "2. Список строк:\n";
    CircularList<std::string> stringList;

    stringList.push_back("Алиса");
    stringList.push_back("Боб");
    stringList.push_back("Виктор");
    stringList.push_back("Галина");

    std::cout << "   Добавлены элементы: Алиса, Боб, Виктор, Галина\n";
    std::cout << "   Размер списка: " << stringList.size() << "\n";
    std::cout << "   Элементы списка: ";
    for (std::size_t i = 0; i < stringList.size(); ++i) {
        std::cout << stringList[i] << " ";
    }
    std::cout << "\n";

    std::cout << "   Первый элемент: " << stringList.front() << "\n";
    std::cout << "   Последний элемент: " << stringList.back() << "\n";

    stringList.push_front("Алексей");
    std::cout << "   После push_front(\"Алексей\"): ";
    for (std::size_t i = 0; i < stringList.size(); ++i) {
        std::cout << stringList[i] << " ";
    }
    std::cout << "\n";

    stringList.insert(2, "Дмитрий");
    std::cout << "   После insert(2, \"Дмитрий\"): ";
    for (std::size_t i = 0; i < stringList.size(); ++i) {
        std::cout << stringList[i] << " ";
    }
    std::cout << "\n";

    std::cout << "   Содержит \"Боб\"? " << (stringList.contains("Боб") ? "Да" : "Нет") << "\n";
    std::cout << "   Содержит \"Евгений\"? " << (stringList.contains("Евгений") ? "Да" : "Нет") << "\n";

    stringList.pop_front();
    std::cout << "   После pop_front(): ";
    for (std::size_t i = 0; i < stringList.size(); ++i) {
        std::cout << stringList[i] << " ";
    }
    std::cout << "\n";

    stringList.remove("Виктор");
    std::cout << "   После удаления \"Виктор\": ";
    for (std::size_t i = 0; i < stringList.size(); ++i) {
        std::cout << stringList[i] << " ";
    }
    std::cout << "\n\n";

    // Пример 3: Циклические свойства
    std::cout << "3. Демонстрация циклических свойств:\n";
    CircularList<int> cycleList;
    cycleList.push_back(1);
    cycleList.push_back(2);
    cycleList.push_back(3);

    std::cout << "   Список: 1, 2, 3 (циклический)\n";
    std::cout << "   После head->next->next->next->next мы вернёмся в начало\n";
    std::cout << "   Элементы в порядке доступа: ";
    int current = cycleList.front();
    for (int i = 0; i < 9; ++i) {
        std::cout << current << " ";
        if (i < 8) {
            current = cycleList.at((i + 1) % cycleList.size());
        }
    }
    std::cout << "\n";

    return 0;
}
